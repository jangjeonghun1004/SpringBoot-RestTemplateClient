package com.example.demo.controller;

import com.example.demo.dto.MemberDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/server")
public class CrudController {

    @GetMapping
    public String getName() {
        return "Flature";
    }

    @GetMapping(value = "/{variable}")
    public String getVariable(@PathVariable String variable) {
        return variable;
    }

    @GetMapping("/param")
    public String getNameWithParam(@RequestParam String name) {
        return "Hello. " + name;
    }


    @PostMapping
    public ResponseEntity<MemberDTO> getMember(
            @RequestBody MemberDTO memberDTO,
            @RequestParam String name,
            @RequestParam String email,
            @RequestParam String organization
    ) {
        System.out.println(memberDTO.getName());
        System.out.println(memberDTO.getEmail());
        System.out.println(memberDTO.getOrganization());

        MemberDTO newMemberDTO = new MemberDTO();
        newMemberDTO.setName(name);
        newMemberDTO.setEmail(email);
        newMemberDTO.setOrganization(organization);

        return ResponseEntity.status(HttpStatus.OK).body(newMemberDTO);
    }

    @PostMapping(value = "/add-header")
    public ResponseEntity<MemberDTO> addHeader(
            @RequestHeader("my-header") String header,
            @RequestBody MemberDTO memberDTO
    ) {
        System.out.println(header);
        return ResponseEntity.status(HttpStatus.OK).body(memberDTO);
    }

}
